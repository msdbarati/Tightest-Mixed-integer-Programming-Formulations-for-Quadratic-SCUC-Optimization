# NOTE: set the following variable to point to the shared CPLEX library
# available on your machine. This will be named something like
# "libcplex2010.so" or "libcplex12100.dylib".
const CPLEX_PATH = ""
